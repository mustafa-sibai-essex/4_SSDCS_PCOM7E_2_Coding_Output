from django.apps import AppConfig


class OperatorviewConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'operatorview'
